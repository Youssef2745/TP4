import java.util.Random;
import java.util.Scanner;


public class chaineMarkov {
	// lance un d�
	Random rand = new Random();
	public int lance_de() {
		return rand.nextInt(6) + 1;
	}
	// lance un d� n fois
	public int[] lance_de_n(int n) {
		
		int i;
		int result[] = new int[n];
		for(i=0;i<n;i++) {
			result[i]=rand.nextInt(6) + 1;
		}
		return result;
	}
	//chercher 6
	public void chercher_face_6(int n) {
		int j = 0 ;
		int r[] = new int[n];
		r = lance_de_n(n);
		for(int i = 0; i<n; i++) {
			if(r[i] == 6)
				j++;
		}
		System.out.println("le nombre d'appartitions de la face 6 est :"+j);
		
	}
	//calcul
	public void calculer(int n) {
		int r[] = new int[n];
		int nb_lanc = 0 ;
		int random = rand.nextInt(6) + 1;
		for(int i = 0; i < n; i++) {
			r[i] = random;	
			if(r[i]!=6) {
				nb_lanc++;
			}
			if(r[i]==6) {
				System.out.println("on a obtenu le nombre 6 apr�s" +nb_lanc);
			}
		}
	}
	//lance_piece
	public String[] lance_piece(int n) {
		String re[] = new String[n];
		String[] result = {"Pile", "Face"};
		int r =rand.nextInt(result.length);
		for(int i = 0; i<n; i++) {
			re[i] = result[r];
		}
		return re;
	}
	//exo2
	public boolean vecteurstok(float [] v,int n) {
		int i=0;
		float val=0;
		while(i<n) {
			if(v[i]>=0 && v[i]<=1) {
				val+=v[i];
				i++;
			}		
		}
		if(val==1) return true;
		return false;

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		chaineMarkov c = new chaineMarkov();
		Scanner sc = new Scanner(System.in);
		System.out.println("Le r�sultat de la lance d'un d� est :"+c.lance_de());
		System.out.println("Entrer le nomber de lancement de d� :");
		int n = sc.nextInt();
		int result[] = new int[n];
		result = c.lance_de_n(n);
		System.out.println("Le r�sultat de la lance d'un d� "+n+" fois est :");
		for(int i = 0; i<n;i++) {
			System.out.println(result[i]);
		}
		System.out.println("Entrer le nomber de lancement de d� :");
		int n2= sc.nextInt();
		c.chercher_face_6(n2);
		String r[] = new String[n2];
		r= c.lance_piece(n2);
		for(int i = 0; i<2;i++) {
			System.out.println(r[i]);
		}
		
	}
		
}
